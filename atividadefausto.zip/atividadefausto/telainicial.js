import React from 'react';
import './App.css'; // Arquivo de estilos CSS

class PaginaInicial extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      novidades: [
        { id: 1, titulo: "Nova coleção de primavera chegou!", descricao: "Confira as últimas tendências da moda primavera.", imagem: "url_para_imagem1.jpg" },
        { id: 2, titulo: "Oferta especial: 20% de desconto em todos os itens", descricao: "Não perca essa chance de economizar!", imagem: "url_para_imagem2.jpg" }
      ]
    };
  }

  render() {
    return (
      <div className="container">
        <h1>Destaques</h1>
        {this.state.novidades.map(novidade => (
          <div className="novidade" key={novidade.id}>
            <img src={novidade.imagem} alt={novidade.titulo} />
            <h2>{novidade.titulo}</h2>
            <p>{novidade.descricao}</p>
          </div>
        ))}
      </div>
    );
  }
}

export default PaginaInicial;
