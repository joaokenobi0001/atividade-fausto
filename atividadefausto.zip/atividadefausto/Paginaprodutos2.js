import React from 'react';
import ReactDOM from 'react-dom';
import PaginaProdutos from './PaginaProdutos';

ReactDOM.render(
  <React.StrictMode>
    <PaginaProdutos />
  </React.StrictMode>,
  document.getElementById('root')
);
