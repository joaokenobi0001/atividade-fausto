import React, { useState } from 'react';

const PaginaProdutos = () => {
  const [produtos] = useState([
    { id: 1, nome: "Camiseta", categoria: "Roupas", preco: 29.99 },
    { id: 2, nome: "Calça Jeans", categoria: "Roupas", preco: 49.99 },
    { id: 3, nome: "Tênis", categoria: "Calçados", preco: 79.99 },
    { id: 4, nome: "Mochila", categoria: "Acessórios", preco: 39.99 }
  ]);
  const [filtroCategoria, setFiltroCategoria] = useState('Todos');

  const handleCategoriaChange = (event) => {
    setFiltroCategoria(event.target.value);
  }

  const produtosFiltrados = filtroCategoria === 'Todos' ? produtos : produtos.filter(produto => produto.categoria === filtroCategoria);

  return (
    <div>
      <h1>Catálogo de Produtos</h1>
      <label htmlFor="categoria">Filtrar por Categoria:</label>
      <select id="categoria" value={filtroCategoria} onChange={handleCategoriaChange}>
        <option value="Todos">Todos</option>
        <option value="Roupas">Roupas</option>
        <option value="Calçados">Calçados</option>
        <option value="Acessórios">Acessórios</option>
      </select>
      <div>
        {produtosFiltrados.map(produto => (
          <div key={produto.id}>
            <h2>{produto.nome}</h2>
            <p>{produto.categoria}</p>
            <p>Preço: R${produto.preco.toFixed(2)}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default PaginaProdutos;
